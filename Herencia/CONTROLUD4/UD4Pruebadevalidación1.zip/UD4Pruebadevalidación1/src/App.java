import net.calculadorassalesianasca.operaciones.SumarElevadosN;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");

        int parametroSeis = 6;
        SumarElevadosN.sumarCuadradosHastaN(parametroSeis);
    }
}
