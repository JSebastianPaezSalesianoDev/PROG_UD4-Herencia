import net.calculadorassalesianasca.operaciones.SumarElevadosN;

public class EjecutableOperaciones {
    public static void main(String[] args) {

        int parametroNumero = 3;
        SumarElevadosN.sumarCuadradosHastaN(parametroNumero);

        float[] numerosEnterosPositivos = {10,4,6,1,7};
        SumarElevadosN.calcularMediaNota(numerosEnterosPositivos);
    }
}
    