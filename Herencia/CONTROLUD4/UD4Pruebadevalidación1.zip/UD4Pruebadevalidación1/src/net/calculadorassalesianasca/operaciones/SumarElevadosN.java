package net.calculadorassalesianasca.operaciones;

public class SumarElevadosN {

    public static int sumarCuadradosHastaN(int n) {

        if (n < 0) {
            System.out.println("Por favor ingresa un numero positivo");
        } else {
            int elevacion = 0;
            for (int i = 1; i <= n; i++) {

                elevacion = i * i;

                /* int elevacion = (int) Math.pow(n, i); */
                System.out.println(elevacion   + elevacion);

            }

        }
        return n;

    }

    public static float calcularMediaNota(float[] numeroEnteros) {
        float suma = 0;
        for (int i = 0; i <= numeroEnteros.length; i++) {

            suma = (numeroEnteros[i] + numeroEnteros[i]);
              System.out.println(suma/numeroEnteros.length);
        }
      
        return suma/5;
    }
}
