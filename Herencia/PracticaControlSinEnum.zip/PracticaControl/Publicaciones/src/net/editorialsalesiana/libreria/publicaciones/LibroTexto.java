package net.editorialsalesiana.libreria.publicaciones;

import java.util.Scanner;

import net.editorialsalesiana.gestion.impuestos.insulares.ImpuestoCanario;
import net.editorialsalesiana.gestion.impuestos.peninsulares.ImpuestoPeninsula;
import net.editorialsalesiana.libreria.Publicacion;

public class LibroTexto extends Publicacion {

    private String asignatura;
    protected String[] temas = new String[110];
    public static LibroTexto[] libroTextos = new LibroTexto[100];

    public LibroTexto(String titulo, int numeroPaginas, String isbn, float precioDistribucion, float precioPublico,
            String fechaEdicion, String asignatura, String[] temas) {
        super(titulo, numeroPaginas, isbn, precioDistribucion, precioPublico, fechaEdicion);
        this.asignatura = asignatura;
        this.temas = temas;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public String[] getTemas() {
        return temas;
    }

    public void setTemas(String[] temas) {
        this.temas = temas;
    }

    public static LibroTexto añadirLibro() {

        Scanner scannerr = new Scanner(System.in);

        System.out.println("Ingrese el titulo del libro");
        String titulo = scannerr.nextLine();

        System.out.println("Cuantas paginas tendra?");
        int numeroPaginas = scannerr.nextInt();
        scannerr.nextLine();

        System.out.println("Ingrese un isbn");
        String isbn = scannerr.nextLine();

        System.out.println("Ingrese un precio de distribucion");
        float precioDistribucion = scannerr.nextFloat();
        scannerr.nextLine();

        System.out.println("Ingrese un precio publico");
        float precioPublico = scannerr.nextFloat();
        scannerr.nextLine();

        System.out.println("Ingrese una fecha de edicion");
        String fechaEdicion = scannerr.nextLine();

        System.out.println("Ingrese el nombre de la asignatura");
        String nombreAsignatura = scannerr.nextLine();

        System.out.println("Que temas tendra ingrese sus titulos separados por comas (,)?");
        String temas = scannerr.nextLine();
        String[] temasArray = temas.split(",");
        LibroTexto librito = new LibroTexto(titulo, numeroPaginas, isbn, precioDistribucion, precioPublico,
                fechaEdicion, nombreAsignatura, temasArray);

        for (int i = 0; i < libroTextos.length; i++) {
            if (libroTextos[i] == null) {
                libroTextos[i] = librito;
                System.out.println("librito agregada");
                break;
            }
        }

        if (temasArray.length > 110) {
            System.out.println("Son demasiados temas pa un libro");
            System.exit(0);
            scannerr.close();
        }
        return librito;
    }

    public String calcularImpuestos() {

        String mensaje = "";
        Scanner scanenr = new Scanner(System.in);
        System.out.println("Ingrese el título del libro al cual le quiera sacar los impuestos");
        String opcionImpuesto1 = scanenr.nextLine();

        for (int i = 0; i < libroTextos.length; i++) {
            if (libroTextos[i] != null && opcionImpuesto1.equalsIgnoreCase(libroTextos[i].getTitulo())) {
                float impuesto1 = ImpuestoPeninsula.sacarIva(libroTextos[i].getPrecioPublico());
                float impuesto2 = ImpuestoCanario.sacarIgic(libroTextos[i].getPrecioPublico());
                mensaje = "El IVA es " + impuesto2 + " y el IGIC es " + impuesto1;
                System.out.println(mensaje);
                break;
            }
        }
        if (libroTextos.length > 100) {
            scanenr.close();
        }
        return mensaje;
    }

    @Override
    public String toString() {
        String mensaje = "__________===<" + getTitulo() + ">===__________\n" +
                "*Asignatura: <" + getAsignatura() + ">\n";

        mensaje += "*Lista de temas:\n";
        for (String tema : temas) {
            mensaje += " \t  - " + tema + "\n";
        }

        mensaje += "*Precio de distribución: <" + getPrecioDistribucion() + ">Euros\n" +
                "*Precio de venta al publico: <" + getPrecioPublico() + ">Euros\n" +
                "========================================================";
        return mensaje;
    }

}
