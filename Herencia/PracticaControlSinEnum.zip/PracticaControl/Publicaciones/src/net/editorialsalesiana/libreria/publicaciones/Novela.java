package net.editorialsalesiana.libreria.publicaciones;

import java.util.Scanner;

import net.editorialsalesiana.libreria.Publicacion;
import net.editorialsalesiana.gestion.impuestos.insulares.ImpuestoCanario;
import net.editorialsalesiana.gestion.impuestos.peninsulares.ImpuestoPeninsula;

public class Novela extends Publicacion {

    protected static String[] tematica;
    protected String autor;
    public static Novela[] novelas = new Novela[110];

    public Novela(String titulo, int numeroPaginas, String isbn, float precioDistribucion, float precioPublico,
            String fechaEdicion, String autor, String tematica[]) {
        super(titulo, numeroPaginas, isbn, precioDistribucion, precioPublico, fechaEdicion);
        this.autor = autor;
        Novela.tematica = tematica;
    }

    public String[] getTematica() {
        return tematica;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public static Novela añadirNovela() {
        Scanner scannerr = new Scanner(System.in);
    
        System.out.println("Ingrese el titulo de la novela");
        String titulo = scannerr.nextLine();
    
        System.out.println("Cuantas paginas tendra?");
        int numeroPaginas = scannerr.nextInt();
        scannerr.nextLine();
    
        System.out.println("Ingrese un isbn");
        String isbn = scannerr.nextLine();
    
        System.out.println("Ingrese un precio de distribucion");
        float precioDistribucion = scannerr.nextFloat();
        scannerr.nextLine();
    
        System.out.println("Ingrese un precio publico");
        float precioPublico = scannerr.nextFloat();
        scannerr.nextLine();
    
        System.out.println("Ingrese una fecha de edicion");
        String fechaEdicion = scannerr.nextLine();
    
        System.out.println("Ingrese el nombre de el/la autor/a");
        String autor = scannerr.nextLine();
    
        System.out.println("Que tipo de tematica tendra esta novela?\n \t 1) Negra\n\t 2) Historica\n\t 3) Juvenil\n" +
                "Por favor ingrese el numero de la tematica que gustaria elegir");
        int tematicaOpcionNumero = scannerr.nextInt();
        scannerr.nextLine();
    
        String tematicaOpcion;
        switch (tematicaOpcionNumero) {
            case 1:
                tematicaOpcion = "Novela negra";
                break;
            case 2:
                tematicaOpcion = "Novela historica";
                break;
            case 3:
                tematicaOpcion = "Novela juvenil";
                break;
            default:
                tematicaOpcion = "ingrese algo valido";
                break;
        }
    
        Novela novelita = new Novela(titulo, numeroPaginas, isbn, precioDistribucion, precioPublico,
                fechaEdicion, autor, new String[]{tematicaOpcion});
    
        for (int i = 0; i < novelas.length; i++) {
            if (novelas[i] == null) {
                novelas[i] = novelita;
                System.out.println("Novela agregada");
                break;
            }
        }
    
        if (novelas.length > 110) {
            System.out.println("Son demasiadas novelas, por favor revise su colección");
            System.exit(0);
            scannerr.close();
        }
        return novelita;
    }
    
    public String calcularImpuestos() {

        String mensaje = "";
        Scanner scanenr = new Scanner(System.in);
        System.out.println("Ingrese el título de la novela al cual le quiera sacar los impuestos");
        String opcionImpuesto1 = scanenr.nextLine();

        for (int i = 0; i < novelas.length; i++) {
            if (novelas[i] != null && opcionImpuesto1.equalsIgnoreCase(novelas[i].getTitulo())) {
                float impuesto1 = ImpuestoPeninsula.sacarIva(novelas[i].getPrecioPublico());
                float impuesto2 = ImpuestoCanario.sacarIgic(novelas[i].getPrecioPublico());
                mensaje = "El IVA es " + impuesto2 + " y el IGIC es " + impuesto1;
                System.out.println(mensaje);
                break;
            }
        }
        if (novelas.length > 100) {
            scanenr.close();
        }
        return mensaje;
    }
    
    @Override
    public String toString() {
        String mensaje = "__________===<" + getTitulo() + ">===__________\n";
        mensaje += "*Tematica: <" + tematica[0] + ">\n" + "*Autor: <" + getAutor() + ">\n" +
                "*Numero de paginas: <" + getNumeroPaginas() + ">\n" + "*Precio de distribucion: <"
                + getPrecioDistribucion() + ">Euros" +
                "\n*Precio de venta al publico: <" + getPrecioPublico() + ">Euros";
    
        return mensaje;
    }
    

}
