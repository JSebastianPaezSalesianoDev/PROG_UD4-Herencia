package net.editorialsalesiana.libreria.publicaciones;

import java.util.Scanner;

import net.editorialsalesiana.libreria.Publicacion;
import net.editorialsalesiana.gestion.impuestos.insulares.ImpuestoCanario;
import net.editorialsalesiana.gestion.impuestos.peninsulares.ImpuestoPeninsula;

public class Revista extends Publicacion {

    private int numeroRevista;
    private String[] nombresArticulos = new String[100];
    public static Revista[] revistas = new Revista[100];

    public Revista(String titulo, int numeroPaginas, String isbn, float precioDistribucion, float precioPublico,
            String fechaEdicion, int numeroRevista, String[] nombresArticulos) {
        super(titulo, numeroPaginas, isbn, precioDistribucion, precioPublico, fechaEdicion);
        this.numeroRevista = numeroRevista;
        this.nombresArticulos = nombresArticulos;
    }

    public Revista(float precioPublico, int numeroRevista, String[] nombresArticulos) {
        super(precioPublico);
        this.numeroRevista = numeroRevista;
        this.nombresArticulos = nombresArticulos;
    }

    public Revista() {

    }

    public int getNumeroRevista() {
        return this.numeroRevista;
    }

    public void setNumeroRevista(int numeroRevista) {
        this.numeroRevista = numeroRevista;
    }

    public String[] getNombreArticulo() {
        return this.nombresArticulos;
    }

    public void setNombresArticulos(String[] nombresArticulos) {
        this.nombresArticulos = nombresArticulos;
    }


    public static Revista[] getRevistas() {
        return revistas;
    }

    
    public static Revista añadirRevista() {
        Scanner scannerr = new Scanner(System.in);

        System.out.println("Ingrese el titulo de la revista");
        String titulo = scannerr.nextLine();

        System.out.println("Cuantas paginas tendra?");
        int numeroPaginas = scannerr.nextInt();
        scannerr.nextLine();

        System.out.println("Ingrese un isbn");
        String isbn = scannerr.nextLine();

        System.out.println("Ingrese un precio de distribucion");
        float precioDistribucion = scannerr.nextFloat();
        scannerr.nextLine();

        System.out.println("Ingrese un precio publico");
        float precioPublico = scannerr.nextFloat();
        scannerr.nextLine();

        System.out.println("Ingrese una fecha de edicion");
        String fechaEdicion = scannerr.nextLine();

        System.out.println("Ingrese el numero de la revista");
        int numeroRevista = scannerr.nextInt();
        scannerr.nextLine();

        System.out.println("Ingrese el nombre de los articulos separados por comas (,)");
        String nombresArticulosSplit = scannerr.nextLine();
        String[] nombresArticulos = nombresArticulosSplit.split(",");

        Revista nuevaRevista = new Revista(titulo, numeroPaginas, isbn, precioDistribucion, precioPublico,
                fechaEdicion,
                numeroRevista, nombresArticulos);
        for (int i = 0; i < revistas.length; i++) {
            if (revistas[i] == null) {
                revistas[i] = nuevaRevista;
                System.out.println("Revista agregada");
                break;
            }
        }

        if (revistas.length == 99) {
            scannerr.close();
        }
        return nuevaRevista;
    }

    public String calcularImpuestos() {

        String mensaje = "";
        Scanner scanenr = new Scanner(System.in);
        System.out.println("Ingrese el título del libro al cual le quiera sacar los impuestos");
        String opcionImpuesto1 = scanenr.nextLine();

        for (int i = 0; i < revistas.length; i++) {
            if (revistas[i] != null && opcionImpuesto1.equalsIgnoreCase(revistas[i].getTitulo())) {
                float impuesto1 = ImpuestoPeninsula.sacarIva(revistas[i].getPrecioPublico());
                float impuesto2 = ImpuestoCanario.sacarIgic(revistas[i].getPrecioPublico());
                mensaje = "El IVA es " + impuesto2 + " y el IGIC es " + impuesto1;
                System.out.println(mensaje);
                break;
            }
        }
        if (revistas.length > 100) {
            scanenr.close();
        }
        return mensaje;
    }
    
    @Override
    public String toString() {

        String mensaje = "__________===<" + getTitulo() + ">===__________\n" + "*Numero de revista: <"
                + getNumeroRevista() + ">\n" +
                "*Lista de articulos: \n";

        for (String titulosArticulos : nombresArticulos) {
            mensaje += " \t  - " + titulosArticulos + "\n";
        }

        mensaje += "*Precio de distribucion: <" + getPrecioDistribucion() + ">Euros\n" + "*Precio de venta al publico: <"
                + getPrecioPublico() +
                ">Euros\n ========================================================";
        return mensaje;
    }
}
