import java.util.Scanner;

import net.editorialsalesiana.gestion.menu.Menu;
import net.editorialsalesiana.libreria.publicaciones.LibroTexto;
import net.editorialsalesiana.libreria.publicaciones.Novela;
import net.editorialsalesiana.libreria.publicaciones.Revista;

public class Publicador {
    public static void main(String[] args) {

        Scanner lector = new Scanner(System.in);

        Menu menu = new Menu();

        boolean seguir = true;

        LibroTexto librito1 = null;
        Revista revistita = null;
        Novela novelita2 = null;

        while (seguir) {
            menu.llamarMenu();
            String opcion = lector.nextLine();

            switch (opcion) {
                case "a":
                    Revista revista = Revista.añadirRevista();
                    System.out.println(revista.getTitulo() + " ha sido agregada");
                    revistita = revista;
                    break;

                case "b":
                    LibroTexto librito = LibroTexto.añadirLibro();
                    System.out.println(librito.getTitulo() + " ha sido agregado");
                    librito1 = librito;
                    break;

                case "c":
                    Novela novelita = Novela.añadirNovela();
                    System.out.println(novelita.getTitulo() + " Ha sido agregada");
                    novelita2 = novelita;
                    break;

                case "d":
                    System.out.println("Lista de revistas:");
                    for (Revista revistita1 : Revista.revistas) {
                        if (revistita1 != null) {
                            System.out.println(revistita1.toString());
                        }
                    }

                    System.out.println("Lista de libros:");
                    for (LibroTexto libroTexto : LibroTexto.libroTextos) {
                        if (libroTexto != null) {
                            System.out.println(libroTexto.toString());
                        }
                    }

                    System.out.println("Lista de novelas:");
                    for (Novela novelita1 : Novela.novelas) {
                        if (novelita1 != null) {
                            System.out.println(novelita1.toString());
                        }
                    }
                    // se que queria un array de publicaciones en general pero no pude :b
                    break;
                case "e":
                    librito1.calcularImpuestos();
                    revistita.calcularImpuestos();
                    novelita2.calcularImpuestos();
                    break;

                default:
                    break;
            }
        }

        lector.close();
    }
}
