package net.editorialsalesiana.libreria.publicaciones;

public enum Tematica {
    NEGRA,
    HISTORICA,
    JUVENIL
}
