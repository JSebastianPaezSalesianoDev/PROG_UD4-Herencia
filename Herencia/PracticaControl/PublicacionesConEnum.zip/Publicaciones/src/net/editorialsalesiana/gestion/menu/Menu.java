package net.editorialsalesiana.gestion.menu;

public class Menu {
    
    public Menu(){
        
    }
    public void llamarMenu(){

        System.out.println("==========QUE DESEA HACER==========\n" +
        "a. Añadir una nueva revista\n" + "b. Añadir un nuevo libro de texto\n" +
        "c. Añadir una nueva novela" + "\nd. Mostrar el listado de todas las publicaciones" + "\ne. Selección de una publicación y " +
        "cálculo de su precio en Canarias y en península.\n" + "f. Salir del progama"   );
    }
}
