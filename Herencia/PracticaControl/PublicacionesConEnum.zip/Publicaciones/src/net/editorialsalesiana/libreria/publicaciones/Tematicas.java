package net.editorialsalesiana.libreria.publicaciones;

public enum Tematicas {
    NEGRA,
    HISTORICA,
    JUVENIL;
}
